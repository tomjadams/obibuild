package scalaz

trait Equal[A] {
  def apply(a1: A, a2: A): Boolean = eq(a1, a2)
  def eq(a1: A, a2: A): Boolean = !neq(a1, a2)
  def neq(a1: A, a2: A): Boolean = !eq(a1, a2)
}

object Equal {
  def EqualA[A] = new Equal[A] {
    override def eq(a1: A, a2: A): Boolean = a1 == a2
  }
  
  implicit def equalBoolean = EqualA[Boolean]
  implicit def equalByte = EqualA[Byte]
  implicit def equalChar = EqualA[Char]
  implicit def equalDouble = EqualA[Double]
  implicit def equalFloat = EqualA[Float]
  implicit def equalInt = EqualA[Int]
  implicit def equalLong = EqualA[Long]
  implicit def equalShort = EqualA[Short]

  implicit def StreamEqual[A](implicit e: Equal[A]) = new Equal[Stream[A]] {
    override def eq(a1: Stream[A], a2: Stream[A]): Boolean =
      if(a1.isEmpty) a2.isEmpty
      else e.eq(a1.head, a2.head) && eq(a1.tail, a2.tail)
  }
}
