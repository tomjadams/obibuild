package scalaz.validation;

import java.lang.Byte.parseByte
import Either.threw

object Parse {
  def parseBoolean(s: String) = threw(java.lang.Boolean.parseBoolean(s))
  def parseByte(s: String) = threw(java.lang.Byte.parseByte(s))
  def parseDouble(s: String) = threw(java.lang.Double.parseDouble(s))
  def parseFloat(s: String) = threw(java.lang.Float.parseFloat(s))
  def parseInt(s: String) = threw(java.lang.Integer.parseInt(s))
  def parseLong(s: String) = threw(java.lang.Long.parseLong(s))
  def parseShort(s: String) = threw(java.lang.Short.parseShort(s))
}
