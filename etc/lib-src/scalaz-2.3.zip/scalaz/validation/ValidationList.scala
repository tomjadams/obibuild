package scalaz.validation;

import list.NonEmptyList

object ValidationList {
  implicit def veither[ERR, A](v: Validation[NonEmptyList, ERR, A]): Either[NonEmptyList[ERR], A] = 
    Validation.veither[NonEmptyList, ERR, A](v)
  
  implicit def validations[ERR, A](e: Either[NonEmptyList[ERR], A]): Validation[NonEmptyList, ERR, A] = 
    Validation.validations[NonEmptyList, ERR, A](e)
  
  implicit def validationso[ERR, A](o: Option[NonEmptyList[ERR]], a: => A): Validation[NonEmptyList, ERR, A] =
    Validation.validationso[NonEmptyList, ERR, A](o, a)
   
  implicit def validationsoa[ERR, A](o: Option[A], e: => NonEmptyList[ERR]): Validation[NonEmptyList, ERR, A] =
    Validation.validationsoa[NonEmptyList, ERR, A](o, e)
    
  implicit def validation[ERR, A](e: Either[ERR, A]): Validation[NonEmptyList, ERR, A] =
    Validation.validation[NonEmptyList, ERR, A](e)
    
  implicit def validationo[ERR, A](o: Option[ERR], a: => A): Validation[NonEmptyList, ERR, A] =
    Validation.validationo[NonEmptyList, ERR, A](o, a)
    
  implicit def validationoa[ERR, A](o: Option[A], e: => ERR): Validation[NonEmptyList, ERR, A] =
    Validation.validationoa[NonEmptyList, ERR, A](o, e)
    
  implicit def validatione[ERR, A](e: ERR): Validation[NonEmptyList, ERR, A] =
    Validation.validatione[NonEmptyList, ERR, A](e)
    
  implicit def validationa[ERR, A](a: A): Validation[NonEmptyList, ERR, A] =
    Validation.validationa[NonEmptyList, ERR, A](a)
    
  implicit def validationf[ERR, A](f: A => Option[ERR], a: A): Validation[NonEmptyList, ERR, A] =
    Validation.validationf[NonEmptyList, ERR, A](f, a)
    
  def sum[ERR, A](vs: List[Validation[NonEmptyList, ERR, A]]) =
    Validation.sum[List, List, NonEmptyList, ERR, A](vs)
}
