package scalaz.javas;

object Iterator {
  implicit def JavaIterator_Stream[A](i: java.util.Iterator): Stream[A] = {
    if(i.hasNext) {
      val x = i.next
      Stream.cons(x.asInstanceOf[A], i)
    } else Stream.empty
  }
}
