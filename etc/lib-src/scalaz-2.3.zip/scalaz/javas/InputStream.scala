package scalaz.javas;

import Closeable.close

object InputStream {
  implicit def InputStream_ByteStream(in: java.io.InputStream): Stream[Byte] = {
    val c = in.read
    if(c == -1) Stream.empty
    else Stream.cons(c.toByte, in)
  }
  
  def withInputStream[X](in: java.io.InputStream, f: Stream[Byte] => X) =
    close(in, f(in))
}
