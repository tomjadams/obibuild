package scalaz.javas;

object Enumeration {
  implicit def Enumeration_Iterator[A](e: java.util.Enumeration) = new Iterator[A] {
    override def hasNext = e.hasMoreElements
    override def next = e.nextElement.asInstanceOf[A] 
  }
}
