package scalaz.javas;

object List {
  implicit def JavaList_ScalaList[A](xs: java.util.List): scala.List[A] = xs match {
    case NonEmpty(h, t) => h.asInstanceOf[A] :: t
    case Empty(_) => Nil
  } 
  
  implicit def ScalaList_JavaList[A](xs: scala.List[A]) = {
    val l = new java.util.LinkedList
    xs.foreach(x => l.add(x))
    l
  }
  
  object NonEmpty {
    def tail(xs: java.util.List) = 
      if(xs.isEmpty) error("tail: empty list") 
      else xs.subList(1, xs.size) 
      
    def unapply(xs: java.util.List): Option[(AnyRef, java.util.List)] =
      if(xs.isEmpty) None
      else Some((xs.get(0), tail(xs)))
  }
  
  object Empty {    
    def unapply(xs: java.util.List): Option[Unit] = NonEmpty.unapply(xs) match {
        case None => Some(())
        case Some(_, _) => None
      }
  }    
}
