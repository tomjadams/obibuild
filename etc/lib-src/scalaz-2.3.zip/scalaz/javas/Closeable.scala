package scalaz.javas;

object Closeable {
  def close[X](os: => java.io.Closeable, x: => X) =
    try {
      x
    } finally {
      os.close
    }
}
