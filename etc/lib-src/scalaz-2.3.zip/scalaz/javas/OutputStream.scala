package scalaz.javas;

import Closeable.close

object OutputStream {
  def write(out: java.io.OutputStream, bytes: Stream[Byte]) =
    close(out, bytes.foreach(out.write(_)))
}
