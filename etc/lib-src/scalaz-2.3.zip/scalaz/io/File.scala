package scalaz.io;

object File {
  import java.io.FileInputStream
  import javas.InputStream._
  import SStream._
  
  def usingFile[X](name: String)(f: Stream[Byte] => X) = {
    val in = new FileInputStream(name)
    
    try {
      f(in)
    } finally {
      in.close
    }
  }
  
  lazy val lineSeparators = List('\r'.toByte, '\n'.toByte)
  
  def usingLines[X](name: String)(f: Stream[Stream[Byte]] => X) = 
    usingFile(name)(bs => f(bs.breaks(lineSeparators.contains(_))
        .filter(cs => !cs.isEmpty && !lineSeparators.contains(cs.head))))
}
