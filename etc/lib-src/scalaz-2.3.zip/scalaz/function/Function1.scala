package scalaz.function

final class Function1[-T1, R](f: scala.Function1[T1, R]) {
  def function = f
  
  def apply(v1: T1) = f(v1)

  override def toString = f.toString
  
  def o[A](g: A => T1) = f compose g
  
  def >>[A](g: R => A): T1 => A = f andThen g
}

object Function1 {
  def apply[T1, R](f: scala.Function1[T1, R]) = new Function1(f)

  implicit def ScalaFunction1_Function1[T1, R](f: scala.Function1[T1, R]) = new Function1(f)

  implicit def Function1_ScalaFunction1[T1, R](f: Function1[T1, R]) = f.function
}
