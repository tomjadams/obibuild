package scalaz.function

object Function {
  def id[A](a: A) = a

  def const[A, B](a: => A)(b: B) = a

  def uncurry[A, B, C](f: A => B => C) = (a: A, b: B) => f(a)(b)
}
