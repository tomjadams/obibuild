package scalaz.lazytuple;

final case class LT4[+A, +B, +C, +D](a: () => A, b: () => B, c: () => C, d: () => D) {
  
  def this(a: A, b: B, c: C, d: D) = 
    this(() => a, () => b, () => c, () => d)

  lazy val _1 = a()
  lazy val _2 = b()
  lazy val _3 = c()
  lazy val _4 = d()
}

object _LT4 {  
  def unapply[A, B, C, D](t: LT4[A, B, C, D]): Option[(A, B, C, D)] = 
    Some(t._1, t._2, t._3, t._4)

  implicit def toTuple[A, B, C, D](t: => LT4[A, B, C, D]) = (t._1, t._2, t._3, t._4)
}
