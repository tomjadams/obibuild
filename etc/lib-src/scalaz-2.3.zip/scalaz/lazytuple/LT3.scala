package scalaz.lazytuple;

final case class LT3[+A, +B, +C](a: () => A, b: () => B, c: () => C) {

  def this(a: A, b: B, c: C) = 
    this(() => a, () => b, () => c)
    
  lazy val _1 = a()
  lazy val _2 = b()
  lazy val _3 = c()
}

object _LT3 {  
  def unapply[A, B, C](t: LT3[A, B, C]): Option[(A, B, C)] = Some(t._1, t._2, t._3)

  implicit def toTuple[A, B, C](t: => LT3[A, B, C]) = (t._1, t._2, t._3)
}