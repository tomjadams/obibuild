package scalaz.lazytuple;

final case class LT2[+A, +B](a: () => A, b: () => B) {

  def this(a: A, b: B) = 
    this(() => a, () => b)
    
  lazy val _1 = a()
  lazy val _2 = b()
  
  def fst[X](f: A => X) = LT2(() => f(a()), b)
  
  def snd[X](f: B => X) = LT2(a, () => f(b()))
}

object _LT2 {  
  def unapply[A, B](t: LT2[A, B]): Option[(A, B)] = Some(t._1, t._2)

  implicit def toTuple[A, B](t: => LT2[A, B]) = (t._1, t._2)
}