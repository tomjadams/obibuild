package scalaz.lazytuple;

object LT {
  def apply[A, B](a: => A, b: => B) = LT2(() => a, () => b)
  def apply[A, B, C](a: => A, b: => B, c: => C) = LT3(() => a, () => b, () => c)
  def apply[A, B, C, D](a: => A, b: => B, c: => C, d: => D) =
    LT4(() => a, () => b, () => c, () => d)
  def apply[A, B, C, D, E](a: => A, b: => B, c: => C, d: => D, e: => E) = 
    LT5(() => a, () => b, () => c, () => d, () => e)
  def apply[A, B, C, D, E, F](a: => A, b: => B, c: => C, d: => D, e: => E, f: => F) = 
    LT6(() => a, () => b, () => c, () => d, () => e, () => f)
  def apply[A, B, C, D, E, F, G](a: => A, b: => B, c: => C, d: => D, e: => E, f: => F, g: => G) = 
    LT7(() => a, () => b, () => c, () => d, () => e, () => f, () => g)
  
}
