package scalaz.lazytuple;

final case class LT6[+A, +B, +C, +D, +E, +F]
  (a: () => A, b: () => B, c: () => C, d: () => D, e: () => E, f: () => F) {
    
  def this(a: A, b: B, c: C, d: D, e: E, f: F) = 
    this(() => a, () => b, () => c, () => d, () => e, () => f)

  lazy val _1 = a()
  lazy val _2 = b()
  lazy val _3 = c()
  lazy val _4 = d()
  lazy val _5 = e()
  lazy val _6 = f()
}

object _LT6 {  
  def unapply[A, B, C, D, E, F](t: LT6[A, B, C, D, E, F]): Option[(A, B, C, D, E, F)] = 
    Some(t._1, t._2, t._3, t._4, t._5, t._6)

  implicit def toTuple[A, B, C, D, E, F](t: => LT6[A, B, C, D, E, F]) = 
    (t._1, t._2, t._3, t._4, t._5, t._6)
}
