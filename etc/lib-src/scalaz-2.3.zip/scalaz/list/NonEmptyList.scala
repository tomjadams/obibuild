package scalaz.list;

sealed trait NonEmptyList[+A] {
  def head: A
  def tail: List[A]  
  def <::[B >: A](b: B): NonEmptyList[B]
  def <:::[B >: A](bs: List[B]): NonEmptyList[B]
  def map[B](f: A => B): NonEmptyList[B]
  def flatMap[B](f: A => NonEmptyList[B]): NonEmptyList[B]
  def toList: List[A]
  def toStream: Stream[A]
  def toIterable: Iterable[A]
}
private final case class NEL[+A](a: A, as: List[A]) extends NonEmptyList[A] {
  override def head = a
  override def tail = as
  override def <::[B >: A](b: B) = NEL(b, this)
  override def <:::[B >: A](bs: List[B]): NonEmptyList[B] = bs match {
    case Nil => this
    case b :: bs => NEL(b, bs ::: a :: as)
  }
  override def map[B](f: A => B): NonEmptyList[B] = NEL(f(a), as.map(f))
  override def flatMap[B](f: A => NonEmptyList[B]): NonEmptyList[B] = 
    f(a).<:::(as.flatMap(((_: NonEmptyList[B]).toIterable).compose(f)))
  override def toList = NonEmptyList.toList(this)
  override def toStream = NonEmptyList.toStream(this)
  override def toIterable = NonEmptyList.toIterable(this)
  override def toString = "NonEmpty" + (a :: as).toString
}

import control.{Semigroup, Functor, Monad}

object NonEmptyList {
  def unapply[A](xs: NonEmptyList[A]): Option[(A, List[A])] = Some(xs.head, xs.tail)
  def apply[A](x: A, xs: A*): NonEmptyList[A] = NEL(x, xs.toList)
  def apply[A](x: A, xs: List[A]): NonEmptyList[A] = NEL(x, xs)
  implicit def toList[A](xs: NonEmptyList[A]): List[A] = xs.head :: xs.tail
  implicit def oToList[A](xs: Option[NonEmptyList[A]]): List[A] = xs match {
    case None => Nil
    case Some(xs) => toList(xs)
  }
  implicit def toStream[A](xs: NonEmptyList[A]): Stream[A] = Stream.cons(xs.head, xs.tail.projection)
  implicit def toIterable[A](xs: NonEmptyList[A]): Iterable[A] = new Iterable[A] {
    override def elements = new Iterator[A] {
      var xxs: Option[NonEmptyList[A]] = Some(xs)
      override def hasNext = xxs == None
      override def next = xxs match {
        case None => error("NonEmptyList.Iterator.next")
        case Some(NonEmptyList(a, Nil)) => {
          xxs = None
          a
        }
        case Some(NonEmptyList(a, b :: bs)) => {
          xxs = Some(NEL(b, bs))
          a
        }
      }
    }
  }
  
  implicit def NonEmptyList_String[A](xs: NonEmptyList[Char]): String = scala.List.toString(xs)
  
  implicit def NonEmptyList_OptionList[A](as: List[A]): Option[NonEmptyList[A]] = as match {
    case Nil => None
    case a :: as => Some(NEL(a, as))
  }

  def nel[A](a: A): NonEmptyList[A] = NEL(a, Nil)
  
  implicit def Functor = new Functor[NonEmptyList] {
    override def map[A, B](ft: => NonEmptyList[A], f: => A => B) = ft.map(f)   	 
  }
  
  def fromList[A](as: List[A], a: => A): NonEmptyList[A] = as match {
    case Nil => NEL(a, Nil)
    case a :: as => NEL(a, as)
  }
  
  def fromList[A](as: List[A]): NonEmptyList[A] = fromList(as, error("fromList with empty List"))
  
  implicit def Monad: Monad[NonEmptyList] = new Monad[NonEmptyList] {
    override def bind[A, B](ma: => NonEmptyList[A], f: A => NonEmptyList[B]) = ma.flatMap(f)
    override def unit[A](a: => A) = nel(a)
  }
  
  implicit def Semigroup[A]: Semigroup[NonEmptyList[A]] = new Semigroup[NonEmptyList[A]] {
    override def append(a1: => NonEmptyList[A], a2: => NonEmptyList[A]): NonEmptyList[A] =
      a1 <::: a2      
  }
}
