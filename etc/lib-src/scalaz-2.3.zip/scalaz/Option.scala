package scalaz;

import control.{Foldable, MonadPlus}
import control.MonadPlus.plusUnit

object Option {
  def some[A](a: A): Option[A] = Some(a)
  
  def none[A]: Option[A] = None
  
  def onull[A](a: A) = if(a == null) None else Some(a)
  
  def fnull[A, B](f: A => B, a: A, n: => B) = onull(f(a)).getOrElse(n)

  def oint(n: Int) = if(n < 0) None else Some(n)
  
  def join[A](o: Option[Option[A]]) = o.flatMap(x => x)

  def somes[A, FD[_], MP[_]](os: FD[Option[A]])(implicit fd: Foldable[FD], mp: MonadPlus[MP]): MP[A] = 
    fd.foldRight[Option[A], MP[A]](os, mp.monadZero.zero, (a, b) => a match {
      case Some(a) => plusUnit[A, MP](a, b)
      case None => b
    })
  
  def threw[A](a: => A): Option[A] = 
    try {
      Some(a)
    } catch {
      case _ => None
    }

  def iif[A](f: A => Boolean)(a: => A) = if(f(a)) Some(a) else None

  def iif[A](c: Boolean)(a: => A) = if(c) Some(a) else None
}

