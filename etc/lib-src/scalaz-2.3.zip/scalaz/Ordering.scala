package scalaz

sealed trait Ordering
final case object LT extends Ordering
final case object EQ extends Ordering
final case object GT extends Ordering

object Ordering {
  implicit def fromInt(n: Int) =
    if(n < 0) LT
    else if(n == 0) EQ
    else GT
}