package scalaz

trait Show[A] {
  def show(a: A): List[Char]
  def apply(a: A) = show(a)
}

object Show {
  implicit def ShowA[A]: Show[A] = new Show[A] {
    override def show(a: A) = a.toString.toList
  }
}
