package scalaz.control

trait Foldable[T[_]] {
  def foldRight[A, B](t: T[A], b: B, f: (A, => B) => B): B
  def foldLeft[A, B](t: T[B], a: A, f: (A, B) => A): A
}

import Maybe._
import function.Function.id

object Foldable {  
  implicit def OptionFoldable: Foldable[Option] = new Foldable[Option] {
    override def foldRight[A, B](t: Option[A], b: B, f: (A, => B) => B): B = t match {
      case None => b
      case Some(a) => f(a, b)
    }
      
    override def foldLeft[A, B](t: Option[B], a: A, f: (A, B) => A) = t match {
      case None => a
      case Some(b) => f(a, b)
    }
  }
  
  implicit def ListFoldable: Foldable[List] = new Foldable[List] {
    override def foldRight[A, B](t: List[A], b: B, f: (A, => B) => B): B = t match {
      case Nil => b
      case x :: xs => f(x, foldRight(xs, b, f))   
    }
    override def foldLeft[A, B](t: List[B], a: A, f: (A, B) => A) = t.foldLeft(a)(f)
  }
 
  implicit def StreamFoldable: Foldable[Stream] = new Foldable[Stream] {
    override def foldRight[A, B](t: Stream[A], b: B, f: (A, => B) => B): B =
      if(t.isEmpty) b else f(t.head, foldRight(t.tail, b, f))
    override def foldLeft[A, B](t: Stream[B], a: A, f: (A, B) => A) = t.foldLeft(a)(f)
  }
  
  implicit def ArrayFoldable: Foldable[Array] = new Foldable[Array] {
    override def foldRight[A, B](t: Array[A], b: B, f: (A, => B) => B): B = t.foldRight(b)((a, b) => f(a, b))
    override def foldLeft[A, B](t: Array[B], a: A, f: (A, B) => A) = t.foldLeft(a)(f)
  }
  
  final class Fd[F[_], A](fa: => F[A])(implicit fd: Foldable[F]) {
    def *:[B](b: B, f: (B, A) => B) = fd.foldLeft(fa, b, f)           
    def :*[B](b: B, f: (A, => B) => B) = fd.foldRight[A, B](fa, b, f)
    def **:(f: (A, A) => A) = fd.foldLeft[Option[A], A](fa, None, (a, b) => Some(a.option(b, f(b, _)))).err("empty")
    def :**(f: (A, A) => A) = fd.foldRight[A, Option[A]](fa, None, (a, b) => Some(b.option(a, f(a, _)))).err("empty")
    def |->[M](f: A => M)(implicit fd: Foldable[F], m: Monoid[M]) =
      fd.foldRight[A, M](fa, m.empty, (a, b) => m.semigroup.append(f(a), b))
    def |+>[M](f: A => M)(implicit fd: Foldable[F], m: Monoid[M]) =
      fd.foldLeft[M, A](fa, m.empty, (a, b) => m.semigroup.append(f(b), a))
    def !(n: Int) = unary_-(n)
    def unary_~ = fd.foldLeft[Int, A](fa, 0, (a, b) => a + 1)
    def unary_+(implicit m: Monoid[A]) = |->(id[A])
    def unary_- = fd.foldRight[A, Stream[A]](fa, Stream.empty, Stream.cons(_, _))
  }
  
  implicit def OptionFd[A](as: => Option[A])(implicit m: Foldable[Option]): Fd[Option, A] = new Fd[Option, A](as)(m)
  
  implicit def ListFd[A](as: => List[A])(implicit m: Foldable[List]): Fd[List, A] = new Fd[List, A](as)(m)
  
  implicit def StreamFd[A](as: => Stream[A])(implicit m: Foldable[Stream]): Fd[Stream, A] = new Fd[Stream, A](as)(m)
  
  implicit def ArrayFd[A](as: => Array[A])(implicit m: Foldable[Array]): Fd[Array, A] = new Fd[Array, A](as)(m)
  
  def maximumBy[T[_], A](as: T[A])(ord: (A, A) => Ordering)(implicit fd: Foldable[T]) =
    ((x: A, y: A) => if(ord(x, y) == GT) x else y) **: new Fd[T, A](as)
    
  def maximum[T[_], A](as: T[A])(implicit fd: Foldable[T], ord: Ord[A]): A = 
    maximumBy[T, A](as)(ord.compare(_, _))
  
  def minimumBy[T[_], A](as: T[A])(ord: (A, A) => Ordering)(implicit fd: Foldable[T]) =
    ((x: A, y: A) => if(ord(x, y) == LT) x else y) **: new Fd[T, A](as)
    
  def minimum[T[_], A](as: T[A])(implicit fd: Foldable[T], ord: Ord[A]): A = 
    minimumBy[T, A](as)(ord.compare(_, _))
  
  def asMap[T[_], SM[_], K, V](e: Map[K, SM[V]], kvs: T[(K, V)])
    (implicit f: Foldable[T], s: Semigroup[SM[V]], md: Monad[SM]): Map[K, SM[V]] =
    f.foldLeft[Map[K, SM[V]], (K, V)](kvs, e, (m, kv) => m + ((kv._1, m.get(kv._1) match {
      case None => md.unit(kv._2)
      case Some(vv) => s.append(md.unit(kv._2), vv)
    })))    
    
  import MonadPlus.plusUnit
  
  def intersperse[M[_], F[_], A](separator: M[A], as: F[A])(implicit fd: Foldable[F], mp: MonadPlus[M]): M[A] =
    fd.foldRight[A, (M[A], Boolean)](as, (mp.monadZero.zero: M[A], true), (a, b) => {
      (mp.plus(plusUnit[A, M](a, if(b._2) mp.monadZero.zero else separator), b._1), false)
    })._1
    
  def takeWhile[A, F[_], M[_]](p: A => Boolean, as: F[A])(implicit f: Foldable[F], m: MonadPlus[M]) =
    f.foldRight[A, M[A]](as, m.monadZero.zero, (a, as) => if(p(a)) plusUnit[A, M](a, as) else m.monadZero.zero)
    
  def filter[A, F[_], M[_]](p: A => Boolean, as: F[A])(implicit f: Foldable[F], m: MonadPlus[M]) =
    f.foldRight[A, M[A]](as, m.monadZero.zero, (a, as) => if(p(a)) plusUnit[A, M](a, as) else as)
  
  def exists[A, F[_]](p: A => Boolean, as: F[A])(implicit f: Foldable[F]) = 
    f.foldRight[A, Boolean](as, false, p(_) || _)
    
  def forall[A, F[_]](p: A => Boolean, as: F[A])(implicit f: Foldable[F]) = 
    f.foldRight[A, Boolean](as, true, p(_) && _)
}

