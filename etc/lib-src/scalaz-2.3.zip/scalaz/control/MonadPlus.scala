package scalaz.control

import lazytuple.LT2

abstract class MonadPlus[M[_]](implicit m: MonadZero[M]) {
  def plus[A](a1: => M[A], a2: => M[A]): M[A]
  def monadZero = m
}

import MonadZero._

object MonadPlus {
  implicit def ListMonadPlus: MonadPlus[List] = new MonadPlus[List] {
    override def plus[A](a1: => List[A], a2: => List[A]) = a1 ::: a2
  }
  
  implicit def StreamMonadPlus: MonadPlus[Stream] = new MonadPlus[Stream] {
    override def plus[A](a1: => Stream[A], a2: => Stream[A]) = a1 append a2
  }
  
  implicit def ArrayMonadPlus: MonadPlus[Array] = new MonadPlus[Array] {
    override def plus[A](a1: => Array[A], a2: => Array[A]) = a1 ++ a2
  }
  
  final class MP[M[_], A](ma: => M[A])(implicit mp: MonadPlus[M]) {
    def <+>(mb: => M[A]) = mp.plus(ma, mb)
    def <+:(a: => A) = mp.plus(mp.monadZero.monad.unit(a), ma)
  }
  
  implicit def ListMP[A](as: => List[A])(implicit m: MonadPlus[List]): MP[List, A] = new MP[List, A](as)(m)
  
  implicit def StreamMP[A](as: => Stream[A])(implicit m: MonadPlus[Stream]): MP[Stream, A] = new MP[Stream, A](as)(m)
  
  implicit def ArrayMP[A](as: => Array[A])(implicit m: MonadPlus[Array]): MP[Array, A] = new MP[Array, A](as)(m)
  
  def unfold[A, B, M[_]](f: B => Option[LT2[A, B]], b: B)(implicit m: MonadPlus[M]): M[A] = 
    f(b) match {
      case None => m.monadZero.zero
      case Some(LT2(a, b)) => m.plus(m.monadZero.monad.unit(a()), unfold[A, B, M](f, b()))
    }
  
  def replicate[A, M[_]](n: Int, a: A)(implicit m: MonadPlus[M]): M[A] =
    if(n <= 0) m.monadZero.zero
    else plusUnit[A, M](a, replicate[A, M](n - 1, a))
        
  def plusUnit[A, M[_]](a: A, ma: M[A])(implicit m: MonadPlus[M]): M[A] = 
    m.plus(m.monadZero.monad.unit(a), ma)
}
