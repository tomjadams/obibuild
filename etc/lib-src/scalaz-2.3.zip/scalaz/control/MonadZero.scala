package scalaz.control

abstract class MonadZero[M[_]](implicit m: Monad[M]) {
  def zero[A]: M[A]
  def monad = m
}

object MonadZero {
  implicit def OptionMonadZero: MonadZero[Option] = new MonadZero[Option] {
    override def zero[A] = None
  }     
  
  implicit def ListMonadZero: MonadZero[List] = new MonadZero[List] {
    override def zero[A] = Nil
  }

  implicit def StreamMonadZero: MonadZero[Stream] = new MonadZero[Stream] {
    override def zero[A] = Stream.empty
  }
  
  implicit def ArrayMonadZero: MonadZero[Array] = new MonadZero[Array] {
    override def zero[A] = new Array(0)
  }
  
  final class MZ[M[_], A](ma: => M[A])(implicit mz: MonadZero[M]) {
    def mzero: M[A] = mz.zero
  }
  
  implicit def OptionMZ[A](as: => Option[A])(implicit m: MonadZero[Option]): MZ[Option, A] = new MZ[Option, A](as)(m)
  
  implicit def ListMZ[A](as: => List[A])(implicit m: MonadZero[List]): MZ[List, A] = new MZ[List, A](as)(m)
  
  implicit def StreamMZ[A](as: => Stream[A])(implicit m: MonadZero[Stream]): MZ[Stream, A] = new MZ[Stream, A](as)(m)
  
  implicit def ArrayMZ[A](as: => Array[A])(implicit m: MonadZero[Array]): MZ[Array, A] = new MZ[Array, A](as)(m)  
}