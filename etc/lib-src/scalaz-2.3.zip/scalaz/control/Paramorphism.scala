package scalaz.control;

trait Paramorphism[T[_], U[_]] {
  def para[A, B](f: ((A, U[A], B) => B), b: B, as: T[A]): B
}

import MonadPlus.plusUnit
import lazytuple.{LT, LT2}

object Paramorphism {
  implicit def OptionOptionParamorphism = new Paramorphism[Option, Option] {
    override def para[A, B](f: ((A, Option[A], B) => B), b: B, as: Option[A]): B = as match {
      case None => b
      case Some(a) => f(a, None, b)
    }
  }
  
  implicit lazy val ListListParamorphism = new Paramorphism[List, List] {
    override def para[A, B](f: ((A, List[A], B) => B), b: B, as: List[A]): B = as match {
      case Nil => b
      case a :: as => f(a, as, para(f, b, as))
    }
  }
  
  implicit lazy val StreamStreamParamorphism = new Paramorphism[Stream, Stream] {
    override def para[A, B](f: ((A, Stream[A], B) => B), b: B, as: Stream[A]): B = 
      if(as.isEmpty) b
      else f(as.head, as.tail, para(f, b, as.tail))
  }

  def FoldableMonadPlusParamorphism[T[_], U[_]](implicit fd: Foldable[T], m: MonadPlus[U]) = new Paramorphism[T, U] {
    override def para[A, B](f: ((A, U[A], B) => B), b: B, as: T[A]): B = {
      fd.foldRight[A, (U[A], B)](as, (m.monadZero.zero, b), (a, asb) =>
        (plusUnit[A, U](a, asb._1), f(a, asb._1, asb._2)))._2
    }
  }
  
  def dropWhile[A, T[_]](f: A => Boolean, as: T[A])(implicit p: Paramorphism[T, T], m: MonadPlus[T]) =
    p.para[A, T[A]]((x, xs, ys) => if(f(x)) ys else plusUnit[A, T](x, xs), m.monadZero.zero, as)
  
  def span[A, M[_], P[_]](f: A => Boolean, as: P[A])(implicit m: MonadPlus[M], p: Paramorphism[P, M]) =
    p.para[A, LT2[M[A], M[A]]]((x, xs, asbs) => if(f(x)) LT(plusUnit[A, M](x, asbs._1), asbs._2) else LT(m.monadZero.zero, plusUnit[A, M](x, xs)), LT(m.monadZero.zero: M[A], m.monadZero.zero: M[A]), as)
    
  def break[A, M[_], P[_]](f: A => Boolean, as: P[A])(implicit m: MonadPlus[M], p: Paramorphism[P, M]) = 
    span[A, M, P](!f(_), as)
}
