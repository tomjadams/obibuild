package scalaz.control;

trait Semigroup[A] {
  def append(a1: => A, a2: => A): A
}

object Semigroup {
  implicit def UnitSemigroup = new Semigroup[Unit] {
    override def append(a1: => Unit, a2: => Unit) = () 
  }
  
  implicit def Function1Semigroup[A, B](implicit sb: Semigroup[B]) = new Semigroup[Function1[A, B]] {
    override def append(f: => Function1[A, B], g: => Function1[A, B]) = 
      x => sb.append(f(x), g(x))
  }
  
  final class SG[A](a1: A)(implicit s: Semigroup[A]) {
    def |+|(a2: A) = s.append(a1, a2)
  }

  implicit def UnitSG(a: => Unit)(implicit s: Semigroup[Unit]): SG[Unit] = new SG[Unit](a)(s)
  
  implicit def Function1SG[A, B](a: => Function1[A, B])(implicit s: Semigroup[Function1[A, B]]): SG[Function1[A, B]] = new SG[Function1[A, B]](a)(s)
}
