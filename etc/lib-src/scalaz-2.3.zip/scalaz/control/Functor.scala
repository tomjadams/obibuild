package scalaz.control

trait Functor[F[_]] {
  def map[A, B](ft: => F[A], f: => A => B): F[B]
}

object Functor {
  implicit def OptionFunctor = new Functor[Option] {
    override def map[A, B](ft: => Option[A], f: => A => B) = ft.map(f)
  }

  implicit def ListFunctor = new Functor[List] {
    override def map[A, B](ft: => List[A], f: => A => B) = ft.map(f)
  }

  implicit def StreamFunctor = new Functor[Stream] {
    override def map[A, B](ft: => Stream[A], f: => A => B) = ft.map(f)
  }

  implicit def ArrayFunctor = new Functor[Array] {
    override def map[A, B](ft: => Array[A], f: => A => B) = ft.map(f)
  }
  
  final class Ftr[F[_], A](fa: => F[A])(implicit ftr: Functor[F]) {
    def |>[B](f: => A => B) = ftr.map(fa, f)
    def ?>(f: A => Unit) = {
      ftr.map(fa, f)
      ()
    }
  }
  
  implicit def OptionFtr[A](as: => Option[A])(implicit f: Functor[Option]): Ftr[Option, A] =
    new Ftr[Option, A](as)(f)
    
  implicit def ListFtr[A](as: => List[A])(implicit f: Functor[List]): Ftr[List, A] =
    new Ftr[List, A](as)(f)     
  
  implicit def StreamFtr[A](as: => Stream[A])(implicit f: Functor[Stream]): Ftr[Stream, A] =
    new Ftr[Stream, A](as)(f)
      
  implicit def ArrayFtr[A](as: => Array[A])(implicit f: Functor[Array]): Ftr[Array, A] =
    new Ftr[Array, A](as)(f)
}
