package scalaz.control

abstract class MonadOr[M[_]](implicit m: MonadZero[M]) {
  def orelse[A](a1: => M[A], a2: => M[A]): M[A]
  def monadZero = m
}

object MonadOr {
  implicit def OptionMonadOr: MonadOr[Option] = new MonadOr[Option] {
    override def orelse[A](a1: => Option[A], a2: => Option[A]) = if(a1.isEmpty) a2 else a1
  }  
  
  implicit def ListMonadOr: MonadOr[List] = new MonadOr[List] {
    override def orelse[A](a1: => List[A], a2: => List[A]) = if(a1.isEmpty) a2 else a1
  }
  
  implicit def StreamMonadOr: MonadOr[Stream] = new MonadOr[Stream] {
    override def orelse[A](a1: => Stream[A], a2: => Stream[A]) = if(a1.isEmpty) a2 else a1
  }
  
  implicit def ArrayMonadOr: MonadOr[Array] = new MonadOr[Array] {
    override def orelse[A](a1: => Array[A], a2: => Array[A]) = if(a1.isEmpty) a2 else a1
  }
  
  final class MO[M[_], A](ma: => M[A])(implicit mo: MonadOr[M]) {
    def |:|(mb: => M[A]) = mo.orelse(ma, mb)
  }
  
  implicit def OptionMO[A](as: => Option[A])(implicit m: MonadOr[Option]): MO[Option, A] = new MO[Option, A](as)(m)
  
  implicit def ListMO[A](as: => List[A])(implicit m: MonadOr[List]): MO[List, A] = new MO[List, A](as)(m)
  
  implicit def StreamMO[A](as: => Stream[A])(implicit m: MonadOr[Stream]): MO[Stream, A] = new MO[Stream, A](as)(m)
  
  implicit def ArrayMO[A](as: => Array[A])(implicit m: MonadOr[Array]): MO[Array, A] = new MO[Array, A](as)(m)  
}
