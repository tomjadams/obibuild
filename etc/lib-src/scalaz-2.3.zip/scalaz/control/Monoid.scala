package scalaz.control

abstract class Monoid[A](implicit s: Semigroup[A]) {
  def empty: A
  def semigroup = s
  def concat[T[_]](as: => T[A])(implicit f: Foldable[T]): A = f.foldRight[A, A](as, empty, (a, b) => s.append(a, b))
}

object Monoid {
  import Semigroup._
  
  implicit def UnitMonoid: Monoid[Unit] = new Monoid[Unit] {
    override def empty = ()
  }
  
  implicit def Function1Monoid[A, B](implicit mb: Monoid[B]): Monoid[Function1[A, B]] = {
      implicit val sb = mb.semigroup
      implicit val sf1: Semigroup[Function1[A, B]] = Function1Semigroup[A, B]
      
      new Monoid[Function1[A, B]] {
        override def empty = x => mb.empty
      }        
  }
}
