package scalaz;

import control.Foldable._

import Stream.{cons, empty}

final class SStream[A](as: => Stream[A]) {
	def stream = as
  
  def breaks(f: A => Boolean) =
    as.:*[Stream[Stream[A]]](cons(empty, empty), (a, as) => {
      lazy val x = f(a) == (!as.head.isEmpty && f(as.head.head))
      cons(cons(a, if(x) as.head else empty), if(as.isEmpty) empty else if(x) as.tail else as)       
    }) 
}

object SStream {
  implicit def SStreamStream[A](as: SStream[A]) = as.stream
  
  implicit def StreamSStream[A](as: Stream[A]) = new SStream(as) 
}
