package scalaz;

import function.Function.const

object Prelude {
  /**
   * <pre>
   * def a = expr
   * effect(a)
   * a
   * </pre>
   * is equivalent to:
   * <pre>
   * using(expr, effect(_))
   * </pre>
   */
  def using[A](a: => A, f: (=> A) => Unit) = {
    f(a)
    a
  }

 /**
  * <pre>
  * val a = expr
  * effect(a)
  * a
  * </pre>
  * is equivalent to:
  * <pre>
  * usings(expr, effect(_))
  * </pre>
  */
  def usings[A](a: A, f: A => Unit) = {
    f(a)
    a
  }

  def ifNull[A, X](a: A, n: => X, nn: A => X) = if(a == null) n else nn(a)
}
