package scalaz

import function.Function.{const, id}

/**
 * <p>
 * The <code>Either</code> type represents a value of one of two possible types (a disjoint union).
 * The data constructors; <code>Left</code> and <code>Right</code> represent the two possible 
 * values. The <code>Either</code> type is often used as an alternative to 
 * <code>scala.Option</code> where <code>Left</code> represents failure (by convention) and
 * <code>Right</code> is akin to <code>Some</code>.
 * </p>
 *
 * @author <a href="mailto:code@tmorris.net">Tony Morris</a>
 * @version 1.0
 */
sealed trait Either[+A, +B] {  
  /**
   * Returns the value from this <code>Left</code> or fails if this is a <code>Right</code>. 
   */
  def left = either(id[A], b => error("Either.left on Right"))
  
  /**
   * Returns the value from this <code>Right</code> or fails if this is a <code>Left</code>. 
   */
  def right = either(a => error("Either.right on Left"), id[B])
  
  /**
   * If this is a <code>Left</code>, then return the value in <code>Right</code> and vice versa.
   */
  def unary_~ = this match {
    case Left(a) => Right(a)
    case Right(b) => Left(b)
  }   
  
  /**
   * Returns <code>true</code> if this is a <code>Left</code>, <code>false</code> otherwise.
   */
  def isLeft: Boolean = either(const(true), const(false))

  /**
   * Returns <code>true</code> if this is a <code>Right</code>, <code>false</code> otherwise.
   */
  def isRight = either(const(false), const(true))
  
  /**
   * Executes the given side-effect if this is a <code>Left</code> with its value.
   *
   * @param f The side-effect to execute.
   */
  def ?<(f: => A => Unit) = either(f, const({}))
  
  /**
   * Executes the given side-effect if this is a <code>Right</code> with its value.
   *
   * @param f The side-effect to execute.
   */
  def ?>(f: B => Unit): Unit = either(const({}), f)
  
  /**
   * Executes the given side-effect if this is a <code>Left</code>.
   *
   * @param e The side-effect to execute.
   */
  def ifLeft(e: => Unit) = either(const(e), const({}))
  
  /**
   * Executes the given side-effect if this is a <code>Right</code>.
   *
   * @param e The side-effect to execute.
   */
  def ifRight(e: => Unit) = either(const({}), const(e))
  
  /**
   * Executes the given side-effect if this is a <code>Left</code> with its value and returns
   * <code>this</code>.
   *
   * @param f The side-effect to execute.
   */
  def usingLeft(f: => A => Unit) = {
    ?<(f)
    this
  }
  
  /**
   * Executes the given side-effect if this is a <code>Right</code> with its value and returns
   * <code>this</code>.
   *
   * @param f The side-effect to execute.
   */ 
  def usingRight(f: => B => Unit) = {
    ?>(f)
    this
  }
  
  /**
   * Deconstruction of the <code>Either</code> type using continutation passing (in contrast to
   * pattern matching).
   */
  def either[X](ax: => A => X, bx: => B => X) = this match {
    case Left(a) => ax(a)
    case Right(b) => bx(b)
  }

  /**
   * Deconstruction of the <code>Either</code> type using continutation passing (in contrast to
   * pattern matching) where the <code>Right</code> value is not used.
   */
  def forLeft[X](left: => A => X, right: => X) = either(left, const(right))
    
  /**
   * Deconstruction of the <code>Either</code> type using continutation passing (in contrast to
   * pattern matching) where the <code>Left</code> value is not used.
   */
  def forRight[X](left: => X, right: => B => X) = either(const(left), right)
  
  /**
   * Deconstruction of the <code>Either</code> type using continutation passing (in contrast to
   * pattern matching) where neither the <code>Right</code> or <code>Left</code> values are not 
   * used.
   */
  def ?[X](left: => X, right: => X) = either(const(left), const(right))
  
  /**
   * Returns the value from this <code>Left</code> or the result of the given argument if this is a
   * <code>Right</code>.
   *
   * @param f The function that is supplied the <code>Right</code> value.
   */
  def left[AA >: A](f: => B => AA) = this match {
    case Left(a) => a
    case Right(b) => f(b)
  }
  
  /**
   * Returns the value from this <code>Right</code> or the result of the given argument if this is a
   * <code>Left</code>.
   *
   * @param f The function that is supplied the <code>Left</code> value.
   */
  def right[BB >: B](f: => A => BB) = this match {
    case Left(a) => f(a)
    case Right(b) => b
  }
  
  /**
   * Returns the value from this <code>Left</code> or the result of the given argument if this is a
   * <code>Right</code>.
   */
  def orLeft[AA >: A](or: => AA) = left(const(or))
  
  /**
   * Returns the value from this <code>Right</code> or the result of the given argument if this is 
   * a <code>Left</code>.
   */
  def orRight[BB >: B](or: => BB) = right(const(or))

  /**
   * Maps the first function argument if this is a <code>Left</code> or the second function 
   * argument if this is a <code>Right</code>.
   */
  def <|>[X, Y](fa: => A => X, fb: => B => Y): Either[X, Y] = this match {
    case Left(a) => Left(fa(a))
    case Right(b) => Right(fb(b))
  }
  
  /**
   * Maps the first function argument if this is a <code>Left</code> or uses the second constant
   * argument if this is a <code>Right</code>.
   */
  def mapx[X, Y](f: => A => X, y: => Y): Either[X, Y] = <|>(f, const(y))
  
  /**
   * Uses the first constant argument if this is a <code>Left</code> or the second function 
   * argument if this is a <code>Right</code>.
   */
  def mapy[X, Y](x: => X, f: B => Y): Either[X, Y] = <|>(const(x), f)
  
  /**
   * Uses the first constant argument if this is a <code>Left</code> or the second constant 
   * argument if this is a <code>Right</code>.
   */
  def mapxy[X, Y](x: => X, y: => Y) = <|>(const(x), const(y))
  
  /**
   * Maps the function argument through <code>Right</code>.
   */
  def |>[Y](f: => B => Y): Either[A, Y] = <|>(id[A], f)
  
  /**
   * Maps the function argument twice through <code>Right</code> (lift2).
   */
  def ||>[AA >: A, C, Y](e: Either[AA, C], f: => (B, C) => Y): Either[AA, Y] = 
    flatMap(b => e |> (f(b, _)))     
  
  /**
   * Maps the function argument three times through <code>Right</code> (lift3).
   */
  def |||>[AA >: A, C, D, Y](ec: Either[AA, C], ed: Either[AA, D], f: => (B, C, D) => Y): Either[AA, Y] = 
    flatMap(b => ec >>= (c => ed |> (f(b, c, _))))      
  
  /**
   * Maps the function argument four times through <code>Right</code> (lift4).
   */
  def ||||>[AA >: A, C, D, E, Y](ec: Either[AA, C], ed: Either[AA, D], ee: Either[AA, E], f: => (B, C, D, E) => Y): Either[AA, Y] = 
    flatMap(b => ec >>= (c => ed >>= (d => ee |> (f(b, c, d, _)))))       
  
  /**
   * Maps the function argument five times through <code>Right</code> (lift5).
   */
  def |||||>[AA >: A, C, D, E, F, Y](ec: Either[AA, C], ed: Either[AA, D], ee: Either[AA, E], ef: Either[AA, F], f: => (B, C, D, E, F) => Y): Either[AA, Y] = 
    flatMap(b => ec >>= (c => ed >>= (d => ee >>= (e => ef |> (f(b, c, d, e, _))))))       
  
  /**
   * Maps the function argument through <code>Left</code>.
   */
  def <|[X](f: => A => X): Either[X, B] = <|>(f, id[B])
  
  /**
   * Maps the function argument twice through <code>Left</code> (lift2).
   */
  def <||[BB >: B, C, X](e: Either[C, BB], f: => (A, C) => X): Either[X, BB] =
    flatMapLeft(a => e <| (f(a, _)))
   
  /**
   * Maps the function argument three times through <code>Left</code> (lift3).
   */
  def <|||[BB >: B, C, D, X](ec: Either[C, BB], ed: Either[D, BB], f: => (A, C, D) => X): Either[X, BB] =
    flatMapLeft(a => ec <<= (c => ed <| (f(a, c, _))))
   
  /**
   * Maps the function argument four times through <code>Left</code> (lift4).
   */
  def <||||[BB >: B, C, D, E, X](ec: Either[C, BB], ed: Either[D, BB], ee: Either[E, BB], f: => (A, C, D, E) => X): Either[X, BB] =
    flatMapLeft(a => ec <<= (c => ed <<= (d => ee <| (f(a, c, d, _)))))
   
  /**
   * Maps the function argument five times through <code>Left</code> (lift5).
   */
  def <|||||[BB >: B, C, D, E, F, X](ec: Either[C, BB], ed: Either[D, BB], ee: Either[E, BB], ef: Either[F, BB], f: => (A, C, D, E, F) => X): Either[X, BB] =
    flatMapLeft(a => ec <<= (c => ed <<= (d => ee <<= (e => ef <| (f(a, c, d, e, _))))))
    
  // todo test
  /**
   * Filters through a <code>Right</code> value.
   */
  def filter[X](f: (=> B) => Boolean)(left: => X): Either[X, B] = this match {
     case Left(_) => Left(left)
     case Right(b) => if(f(b)) Right(b) else Left(left)
  }

  // todo test
  /**
   * Filters through a <code>Left</code> value.
   */
  def filterLeft[X](f: (=> A) => Boolean)(right: => X): Either[A, X] = this match {
    case Left(a) => if(f(a)) Left(a) else Right(right)
    case Right(_) => Right(right)
  }
   
   // todo test
   def mapIf[AA >: A](f: (=> B) => Boolean)(left: => AA): Either[AA, B] =
     flatMap(x => if (f(x)) Right(x) else Left(left))
    
   // todo test
   def mapIfLeft[BB >: B](f: (=> A) => Boolean)(right: => BB): Either[A, BB] = 
     flatMapLeft(x => if (f(x)) Left(x) else Right(right))
    
  /**
   * Maps the constant argument through <code>Right</code>.
   */
  def +>[X, Y](x: => X): Either[X, B] = <|(const(x))
  
  /**
   * Maps the constant argument through <code>Left</code>.
   */
  def <+[X, Y](y: => Y): Either[A, Y] = |>(const(y))
  
  /**
   * Executes the given side-effect if this is a <code>Right</code> with its value.
   *
   * @param f The side-effect to execute.
   */
  def foreach(f: => B => Unit) = ?>(f)

  /**
   * Binds the given function across <code>Right</code>. Synonym for <code>flatMap</code>.
   *
   * @param The function to bind across <code>Right</code>.
   */
  def >>=[AA >: A, X](f: => B => Either[AA, X]) = flatMap[AA, X](f)
  
  /**
   * Binds the given constant across <code>Right</code>. This is like calling <code>flatMap</code>
   * where the argument to the given function is ignored.
   *
   * @param The constant to bind across <code>Right</code>.
   */
  def >>[AA >: A, X](e: => Either[AA, X]) = >>=[AA, X](b => e)
  
  /**
   * Binds the given function across <code>Right</code>.
   *
   * @param The function to bind across <code>Right</code>.
   */
  def flatMap[AA >: A, X](f: => B => Either[AA, X]) = this match {
    case Left(a) => Left(a)
    case Right(b) => f(b)
  }
  
  /**
   * Binds the given function across <code>Left</code>. Synonym for <code>flatMapLeft</code>.
   *
   * @param The function to bind across <code>Left</code>.
   */
  def <<=[BB >: B, X](f: => A => Either[X, BB]) = flatMapLeft[BB, X](f)
  
  /**
   * Binds the given constant across <code>Left</code>. This is like calling 
   * <code>flatMapLeft</code> where the argument to the given function is ignored.
   *
   * @param The constant to bind across <code>Left</code>.
   */
  def <<[BB >: B, X](e: => Either[X, BB]) = <<=[BB, X](a => e)
  
  /**
   * Binds the given function across <code>Left</code>.
   *
   * @param The function to bind across <code>Left</code>.
   */
  def flatMapLeft[BB >: B, X](f: => A => Either[X, BB]) = this match {
    case Left(a) => f(a)
    case Right(b) => Right(b)
  }
   
  /**
   * Function application within Either on the right.
   *
   * @param e The Either of the function to apply on the right.
   */
  def ap[AA >: A, X](e: Either[AA, B => X]) = 
    e.flatMap(f => flatMap(b => Right(f(b))))
    
  /**
   * Function application within Either on the left.
   *
   * @param e The Either of the function to apply on the left.
   */
  def apLeft[BB >: B, X](e: Either[A => X, BB]) =
    e.flatMapLeft(f => flatMapLeft(a => Left(f(a))))    

  /**
   * Returns a <code>Seq</code> containing the <code>Right</code> value if it exists or an empty
   * <code>Seq</code> if this is a <code>Left</code>.
   */
  def toSeq = this match {
    case Left(_) => Seq.empty
    case Right(b) => Seq.singleton(b)
  }
  
  /**
   * Returns a <code>Seq</code> containing the <code>Left</code> value if it exists or an empty
   * <code>Seq</code> if this is a <code>Right</code>.
   */
  def toSeqLeft = (~this).toSeq
  
  /**
   * Returns a <code>Some</code> containing the <code>Right</code> value if it exists or a 
   * <code>None</code> if this is a <code>Left</code>.
   */
  def toOption = this match {
    case Left(_) => None
    case Right(b) => Some(b)
  }
   
  /**
   * Returns a <code>Some</code> containing the <code>Left</code> value if it exists or a 
   * <code>None</code> if this is a <code>Right</code>.
   */
  def toOptionLeft = (~this).toOption
}
final case class Left[+A, +B](a: A) extends Either[A, B]
final case class Right[+A, +B](b: B) extends Either[A, B]

import control.{Foldable, MonadPlus}
import control.MonadPlus.plusUnit

object Either {
  /**
   * Constructs a <code>Left</code> value with an upcast to <code>Either</code>.
   */
  def left[A, B](a: A): Either[A, B] = Left(a)

  /**
   * Constructs a <code>Right</code> value with an upcast to <code>Either</code>.
   */
  def right[A, B](b: B): Either[A, B] = Right(b)

  /**
   * Joins an <code>Either</code> through <code>Right</code>.
   */
  def join[A, B](es: => Either[A, Either[A, B]]): Either[A, B] = es >>= id[Either[A, B]]
  
  /**
   * Joins an <code>Either</code> through <code>Left</code>.
   */
  def joinLeft[A, B](es: => Either[Either[A, B], B]): Either[A, B] = es <<= id[Either[A, B]]
  
  /** 
   * Sums the (<code>MonadZero</code<) <code>Left</code> values in the given foldable 
   * container. 
   */ 
  def lefts[A, B, FD[_], MP[_]](os: FD[Either[A, B]])(implicit fd: Foldable[FD], mp: MonadPlus[MP]): MP[A] = 
    fd.foldRight[Either[A, B], MP[A]](os, mp.monadZero.zero, 
        (a, b) => a.forLeft(a => plusUnit[A, MP](a, b), b))     
  
  /** 
   * Sums the (<code>MonadZero</code<) <code>Right</code> values in the given foldable 
   * container. 
   */ 
  def rights[A, B, FD[_], MP[_]](os: FD[Either[A, B]])(implicit fd: Foldable[FD], mp: MonadPlus[MP]): MP[B] = 
    fd.foldRight[Either[A, B], MP[B]](os, mp.monadZero.zero, 
        (a, b) => a.forRight(b, a => plusUnit[B, MP](a, b)))

  /**
   * Sums the (<code>MonadZero</code<) <code>Left</code> and <code>Right</code> values in the given foldable 
   * container.
   */
  def leftsRights[A, B, FD[_], MP[_]](os: FD[Either[A, B]])(implicit fd: Foldable[FD], mp: MonadPlus[MP]): (MP[A], MP[B]) = 
    fd.foldRight[Either[A, B], (MP[A], MP[B])](os, (mp.monadZero.zero, mp.monadZero.zero), 
        (a, b) => (a, b) match {
          case (Left(a), (as, bs)) => (plusUnit[A, MP](a, as), bs)          
          case (Right(b), (as, bs)) => (as, plusUnit[B, MP](b, bs))         
        })
    
  /**
   * An alternative (preferred) way to handle an exception that may be thrown in the evaluation of
   * the given argument.
   */
  def threw[A](a: => A): Either[Throwable, A] = 
    try {
      Right(a)
    } catch {
      case e => Left(e)
    }
    
  /**
   * Throw the exception if left, otherwise, the right value.
   */
  def throwe[A](e: Either[Throwable, A]): A = e match {
    case Left(t) => throw t
    case Right(a) => a
  }
  
  /**
   * Throw the exception if left, otherwise, no side-effect.
   */
  def throwu[A](e: Either[Throwable, A]): Unit = throwe(e)
  
  /**
   * Takes an <code>Either</code> to its contained type within <code>Left</code> or 
   * <code>Right</code>.
   */
  def reduce[A](e: Either[A, A]) = e match {
    case Left(a) => a
    case Right(a) => a
  }
   
  /**
   * If the condition satisfies, return the given B in <code>Right</code>, otherwise, return
   * the given A in <code>Left</code>.
   */
  def iif[A, B](cond: Boolean)(right: => B, left: => A) = if(cond) Right(right) else Left(left)
}
