package scalaz;

final class Effect(u: => Unit) {
  def effect = u
  def unless(c: Boolean) = if(!c) u
}

object Effect {
  implicit def UnitEffect(u: => Unit) = new Effect(u)
  implicit def EffectUnit(e: Effect) = e.effect
}
