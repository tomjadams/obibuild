package scalaz;

import function.Function.const
import control.Monad._

final class Maybe[A](o: Option[A]) {
  def option = o
  
  def maybe[X](none: => X, some: => A => X) = o match {
    case None => none
    case Some(a) => some(a)
  }
  
  def option[X](none: => X, some: => A => X) = maybe(none, some)
  
  def forall(f: A => Boolean) = o match {
    case None => false
    case Some(a) => f(a)
  }
  
  def ?[X](none: => X, some: => X) = maybe(none, const(some))
  
  def toEither[X](left: => X): Either[X, A] = o match {
    case None => Left(left)
    case Some(a) => Right(a)
  }
  
  def toEitherLeft[X](right: => X) = o match {
    case None => Right(right)
    case Some(b) => Left(b)
  }
    
  def ifNone(n: => Unit) = option(n, const({}))
  
  def usingSome(f: => A => Unit) = {
    o.foreach(f)
    o
  }
  
  def usingNone(f: => Unit) = {
    f
    o
  }
  
  def err(message: => String) = o.getOrElse(error(message))
  
  def |(a: => A) = o getOrElse a
}

object Maybe {
  implicit def MaybeOption[A](m: Maybe[A]) = m.option
  
  implicit def OptionMaybe[A](o: Option[A]) = new Maybe(o)
}