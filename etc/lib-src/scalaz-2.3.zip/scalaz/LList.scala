package scalaz;

final class LList[A](as: List[A]) {
	def list = as
  
  def breaks(f: A => Boolean) = 
    as.foldRight[List[List[A]]](Nil :: Nil)((a, as) => {
      lazy val x = f(a) == (!as.head.isEmpty && f(as.head.head))
      (a :: (if(x) as.head else Nil)) :: (if(as.isEmpty) Nil else if(x) as.tail else as)       
    }) 
  
  def *|*(n: Int): List[List[A]] =
    as.splitAt(n) match {
      case (as, Nil) => as :: Nil
      case (as, bs) => as :: new LList(bs) *|* n
    }
  
  def =|=(aas: List[A]) =
    as.length == aas.length && as.forall(a => aas.filter(_ == a) == as.filter(_ == a))
  
  def ?[X](nil: => X, cons: => X) = as match {
    case Nil => nil
    case _ :: _ => cons
  }
  
  import scala.List.flatten
  import control.Foldable.intersperse
  
  def insert(n: Int, a: A): List[A] =
    flatten(intersperse[List, List, List[A]]((a :: Nil) :: Nil, new LList(as) *|* n))
    
  def insertEvery(n: Int, a: A, breakWhen: A => Boolean): List[A] = 
    flatten(new LList(as).breaks(breakWhen).map(t => if(t.exists(!breakWhen(_))) new LList(t).insert(n, a) else t))
}

object LList {
  implicit def LListList[A](as: LList[A]) = as.list
  
  implicit def ListLList[A](as: List[A]) = new LList(as)
}